package com.siyoma.tenanttracker;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;

public class RentReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String title=intent.getStringExtra("title");
        String message=intent.getStringExtra("message");
        boolean sound=intent.getBooleanExtra("sound",true), vibration=intent.getBooleanExtra("vibration",true);
        Intent open=new Intent(context,MainActivity.class); open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi=PendingIntent.getActivity(context, 9001, open, PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b=new NotificationCompat.Builder(context,"siyoma_rent_reminders")
            .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title==null?"Rent Reminder":title)
            .setContentText(message==null?"Rent reminder":message).setStyle(new NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(pi);
        if(sound) b.setSound(android.provider.Settings.System.DEFAULT_NOTIFICATION_URI);
        if(vibration) b.setVibrate(new long[]{0,400,250,400});
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify((int)(System.currentTimeMillis()%100000),b.build());
    }
}
